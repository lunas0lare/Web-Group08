const express = require('express')
const router = express.Router()

const loginController = require('../controllers/user.controller')

router.get("/", loginController.loginControllerGET)
router.post("/", loginController.loginControllerPOST)

module.exports = router