const indexRoute = require("./index.route")
const loginRoute = require("./login.route")

function route(app){
    app.use("/", indexRoute)
    app.use("/login", loginRoute)
}

module.exports = route